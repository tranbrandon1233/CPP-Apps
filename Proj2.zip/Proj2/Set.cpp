#include <iostream>

#include "Set.h"

using namespace std;

Set::Set() 
    : m_head(new Node), m_size(0)
// Set constructor
{
	// initialize the first node pointers
  m_head->next = m_head;
  m_head->prev = m_head;
}

Set::Set(const Set &inputSet) 
    : Set()
{
    if (inputSet.m_head == m_head) {  //Return if the input set is the same as the current set
        return;
 }
  for (Node* currNode = inputSet.m_head->next; currNode != inputSet.m_head; currNode = currNode->next) {  //for each node in input set, insert node to current set
       // Insert node before the given inputSet
      Node* node = new Node;
      node->val = currNode->val;    //Set up node to contain the correct value and pointers to neighboring nodes
      node->prev = m_head->prev;
      node->next = m_head;
      node->prev->next = node;   //Set node pointers to connect new node to set
      node->next->prev = node;
      m_size += 1;   //Increase size
  }
}

Set::~Set()
{
    Node* next;
    for (Node* currNode = m_head->next; currNode != m_head; currNode = next){  //For all nodes in set, set next node and delete current one
        next = currNode->next;
        // Detach node from list, delete it, and reduce size of list
        currNode->prev->next = currNode->next;
        currNode->next->prev = currNode->prev;
        delete currNode;
        m_size -= 1;
    }
    delete m_head;  // delete m_head
}

Set &Set::operator=(const Set &inputSet)
{
  if (&inputSet == this) ///Return if inputSet is the same
    return *this;
  Node* next;
  for (Node* currNode = m_head->next; currNode != m_head; currNode = next) {  //For all nodes in set, set next node and delete current one
      next = currNode->next;
      // Detach node from list, delete it, and reduce size of list
      currNode->prev->next = currNode->next;
      currNode->next->prev = currNode->prev;
      delete currNode;
      m_size -= 1;
  }
  for (Node* currNode = inputSet.m_head->next; currNode != inputSet.m_head; currNode = currNode->next) { //for every node in the input set, insert it into the current set
      Node* node = new Node;
      node->val = currNode->val;    //Set up node to contain the correct value and pointers to neighboring nodes
      node->prev = m_head->prev;
      node->next = m_head;
      node->prev->next = node;   //Set node pointers to connect new node to set
      node->next->prev = node;
      m_size += 1;   //Increase size
  }
  return *this;
}

bool Set::insert(const ItemType &val)
{
  Node* currNode;
  for (currNode = m_head->next; currNode != m_head; currNode = currNode->next) { //Iterate through nodes to find correct node
    if (currNode->val == val) //Return false if it exists already
      return false;
    if (currNode->val > val)  //Break if it is less than the value of the current node
      break;
  }
  Node* node = new Node;
  node->val = val;    //Set up node to contain the correct value and pointers to neighboring nodes
  node->prev = currNode->prev;
  node->next = currNode;
  node->prev->next = node;   //Set node pointers to connect new node to set
  node->next->prev = node;
  m_size += 1;   //Increase size
  return true;
}

bool Set::erase(const ItemType &val)
{
    Node* node = m_head;
    //Find node containg val
    for (Node* currNode = m_head->next; currNode != m_head; currNode = currNode->next) {
        if (currNode->val == val)
            node = currNode;
    }
    if (node == m_head || node == NULL) { //If the node was not found
        return false;
    }
    //Find the node with the value, delete it, reduce size of list, and return true
    node->prev->next = node->next;
    node->next->prev = node->prev;
    delete node;
    m_size -= 1;
    return true;
}

bool Set::contains(const ItemType &val) const
{
  //Returns whether node with given val is found and not the head node
    Node* node = m_head;
      //Find node containg val
    for (Node* currNode = m_head->next; currNode != m_head; currNode = currNode->next) {
        if (currNode->val == val)
            node = currNode;
    }
    return node != m_head; //Return if found
}

bool Set::get(int i, ItemType &val) const
{
  if (i < 0 || i >= size())  //Return false if i is not valid
    return false;
  Node* currNode = m_head->next;
  for (; i > 0; i -= 1)  //For all of i, assign pointer to the next node
    currNode = currNode->next;
  val = currNode->val;
  return true;
}

void Set::swap(Set &other)
{
    if (other.m_head == m_head) //Return if the sets are the same
	    return;
  // swap the head nodes
  Node* temp;
  temp = m_head;
  m_head = other.m_head;
  other.m_head = temp;

  // swap sizes
  int tempSize;
  tempSize = m_size;
  m_size = other.m_size;
  other.m_size = tempSize;
}





void unite(const Set &s1, const Set &s2, Set &result)
{
  Set newSet;
  ItemType tempVal;
  if (&s1 == &s2) { //If the sets are the same, assign the result to one of the sets
      result = s1;
      return;
  }
  for (int i = 0; i < s1.size(); i += 1) {  //Get vals of all nodes in s1 and attempt to insert into new set
    s1.get(i, tempVal);
    newSet.insert(tempVal);
  }
  for (int i = 0; i < s2.size(); i += 1) {  //Get vals of all nodes in s2 and attempt to insert into new set
    s2.get(i, tempVal);
    newSet.insert(tempVal);
  }
  result = newSet;   //Set the result to this new set
}

void butNot(const Set& s1, const Set& s2, Set& result)
// Inserts data in set s1 that is not in set s2 into result
{

    Set newSet;
    ItemType tempVal;
    if (&s1 == &s2) { //If the sets are the same, set the result to an empty set
        result = newSet;
    }
    for (int i = 0; i < s1.size(); i += 1) {  //Get vals of all nodes in s1 and attempt to insert into new set if the value is not in set s2
        s1.get(i, tempVal);
        if(!s2.contains(tempVal))
            newSet.insert(tempVal);
    }
    result = newSet;   //Set the result to this new set
}
