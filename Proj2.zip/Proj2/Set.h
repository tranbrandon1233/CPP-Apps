#ifndef SET_H
#define SET_H

#include <string>

using ItemType = std::string;

class Set {
public:
  Set();
  // Constructor of set

  Set(const Set &inputSet);
  // Copy constructor

  ~Set();
  // Destructor deletes all nodes

  Set &operator= (const Set &inputSet);
  // Assignment operator 

  inline bool empty() const { return size() == 0; };
  // Return whether the set is empty

  inline int size() const { return m_size; }
  // Return size of set

  bool insert(const ItemType &val);
  // Insert val into the set if not already present.  Return true if the value
  // was actually inserted; otherwise, since the value must be already present,
  // return false.

  bool erase(const ItemType &val);
  // Remove the value from the set if present.  Return true if the value was 
  // removed; otherwise, leave the set unchanged and return false.

  bool contains(const ItemType &val) const;
  // Return true if the value is in the set, otherwise false.

  bool get(int i, ItemType &val) const;
  // If 0 <= i < size(), copy into value the item in the set that is strictly 
  // greater than exactly i items in the set and return true. Otherwise, leave 
  // value unchanged and return false.

  void swap(Set &other);
  // Exchange the contents of this set with the other one.


private:
  struct Node {
    ItemType val;
    Node *prev, *next;
  };

  Node* m_head;
  int m_size;

  
  
};

void unite(const Set& s1, const Set& s2, Set& result);
// Combines data  of set s1 and set s2 into result set with no duplicates

void butNot(const Set& s1, const Set& s2, Set& result);
// Inserts data in set s1 that is not in set s2 into result

#endif /* !SET_H */
